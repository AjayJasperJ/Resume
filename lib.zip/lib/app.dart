import 'package:flutter/widgets.dart';

//default datas
late Size displaysize;

Color apptheme_light_background = Color.fromRGBO(246, 247, 249, 1);
